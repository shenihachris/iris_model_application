# from flask import Flask, render_template, request
# import pickle
# import numpy as np

# app = Flask(__name__)
# model = pickle.load(open("iris_model.pkl", "rb"))


# @app.route("/")
# def home():
#     render_template("index.html")


# @app.route("/predict", method=["post"])
# def predict():
#     sl = float(request.form['sl'])
#     sw = float(request.form['sw'])
#     pl = float(request.form['pl'])
#     pw = float(request.form['pw'])

#     input_features = [[sl, sw, pl, pw]]
#     prediction = model.predict(input_features)[0]

#     species_map = {0: "Setosa", 1: "Versicolor", 2: "Virginica"}
#     predicted_species = species_map.get(prediction, "unknown")
#     return render_template("index.html", prediction=predicted_species)


# if __name__ == "__main__":
#     app.run()


from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__)
model = pickle.load(open("iris_model.pkl", "rb"))


@app.route("/")
def home():
    return render_template("index.html")  # Added return statement


@app.route("/predict", methods=["POST"])  # Corrected "method" to "methods"
def predict():
    sl = float(request.form['sl'])
    sw = float(request.form['sw'])
    pl = float(request.form['pl'])
    pw = float(request.form['pw'])

    input_features = [[sl, sw, pl, pw]]
    prediction = model.predict(input_features)[0]

    species_map = {0: "Setosa", 1: "Versicolor", 2: "Virginica"}
    predicted_species = species_map.get(prediction, "unknown")
    return render_template("index.html", prediction=predicted_species)


if __name__ == "__main__":
    app.run()
