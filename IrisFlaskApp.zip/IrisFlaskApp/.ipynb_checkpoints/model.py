import numpy as np
import matplotlib as plt
import pandas as pd
import seaborn as sns
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import pickle

df = pd.read_csv("iris.csv")

print(df.head())

df.describe()

df.info()

df["Classification"] = df["Species"].replace(
    {"iris-setosa": 0, "iris-versicolor": 1, "iris-virginica": 2}
)

x = df[["SepalLengthCm", "SepalWidthCm", "PetalLengthCm", "PetalWidthCm"]]
y = df["Classification"]

x_train, x_test, y_train, y_test = train_test_split(
    x, y, test_size=0.2, random_state=42
)
model = RandomForestClassifier(
    n_estimators=100, random_state=12, criterion="entropy")
model.fit(x, y)

y_pred = model.predict(x_test)

acc = accuracy_score(y_test, y_pred)
print("model accuracy:", acc)

with open("iris_model.pkl", "wb") as f:
    pickle.dump(model, f)
